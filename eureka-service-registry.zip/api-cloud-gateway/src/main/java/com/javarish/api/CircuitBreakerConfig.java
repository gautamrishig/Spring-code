package com.javarish.api;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CircuitBreakerConfig {

//    @Bean
//    public Resilience4JCircuitBreakerFactory resilience4JCircuitBreakerFactory(CircuitBreakerRegistry circuitBreakerRegistry) {
//        return new Resilience4JCircuitBreakerFactory(circuitBreakerRegistry);
//    }
}
