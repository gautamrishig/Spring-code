package com.javarish.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCloudConfigGitServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
