package com.javarish.api.pattern.factory;

public class Cat implements Animal {

	@Override
	public String speak() {
		return "cat speak Memo meaoo";
	}

}
