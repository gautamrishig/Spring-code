package com.javarish.api.pattern.factory;

public class Dog implements Animal {

	@Override
	public String speak() {
		return "Dog speak bawo bawo";
	}

}
