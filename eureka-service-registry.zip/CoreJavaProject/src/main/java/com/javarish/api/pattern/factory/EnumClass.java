package com.javarish.api.pattern.factory;

public class EnumClass {

	enum AnimalTpyeCat {
		DOG, CAT, TIGER, LION
	};
}
