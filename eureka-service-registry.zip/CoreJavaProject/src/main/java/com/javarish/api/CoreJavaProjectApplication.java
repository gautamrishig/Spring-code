package com.javarish.api;

//@SpringBootApplication
public class CoreJavaProjectApplication {

//	public static void main(String[] args) {
//		SpringApplication.run(CoreJavaProjectApplication.class, args);
//	}

}
