package com.javarish.api.pattern.factory;

public interface Animal {
	public String speak();

}
